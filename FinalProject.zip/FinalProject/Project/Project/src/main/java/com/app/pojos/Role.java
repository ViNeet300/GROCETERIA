package com.app.pojos;

public enum Role {
	ADMIN, CUSTOMER, SUPPLIER, DELIVERY_BOY
}
