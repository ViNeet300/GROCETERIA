package com.app.pojos;

public enum PaymentStatus {
	PAID, UNPAID
}
