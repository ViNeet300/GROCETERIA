package com.app.pojos;

public enum PaymentType {
	CREDIT, DEBIT
}
