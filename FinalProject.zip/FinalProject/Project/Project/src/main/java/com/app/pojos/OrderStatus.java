package com.app.pojos;

public enum OrderStatus {
	PENDING, DELIVERED
}
